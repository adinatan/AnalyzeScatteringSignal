# Fast PILATUS TIFF differences in MATLAB

Bounded-memory, non-overlapping even-minus-odd window averages. No GPU needed.
Designed for MATLAB R2026a. Parallel Computing Toolbox is needed only when
`Workers > 1`. No extra libraries or installation steps.

## Start

Extract this folder and put it on your MATLAB path, or make it the current folder.
Edit the two paths in `run_pilatus_diff_example.m`, then run that script.

Equivalent minimal call:

```matlab
files = pilatus_filelist("D:\pilatus\run001", "*.tif");
r = pilatus_diff(files, "E:\analysis\run001_w3", 3, Workers=2);
[D1, sourceFiles] = read_pilatus_diff("E:\analysis\run001_w3", 1);
```

The output folder must be new or empty. Source files are never modified.
Process each acquisition/condition separately. Only completed, single-page,
monochrome TIFF files are intended. No per-frame intensity normalization is done.

## Window versus output chunk size

- `window=1`: `I2-I1`, `I4-I3`, `I6-I5`, ...
- `window=3`: `(I2+I4+I6-I1-I3-I5)/3`, then
  `(I8+I10+I12-I7-I9-I11)/3`, ...
- `ChunkFrames=64`: save up to 64 resulting difference images in each output file.
  This is independent of the averaging window.

A window counts PAIRS, not input images. Windows do not overlap. They refer to
positions in `files`, not the odd/even parity of numbers in filenames. For a run
numbered 0,1,2,..., the first difference is file 1 minus file 0. Confirm which
state is added and which is subtracted before processing the entire run.

Trailing incomplete windows are omitted with a warning and recorded in
`manifest.ignoredFiles`. Use `TailPolicy="error"` to stop instead. With 100,000
inputs and window 3, there are 16,666 complete outputs and four unused inputs.
Never let a window cross a change of delay, sample, exposure, or acquisition state.

## Output

Default output is `diff_000001.mat`, `diff_000002.mat`, ... plus `manifest.mat`.
Each data chunk contains `D`, ordered `[height, width, output index within chunk]`.

```matlab
S = load("E:\analysis\run001_w3\diff_000001.mat", "D");
D1 = S.D(:,:,1);
```

For bulk subsequent analysis, load each chunk once and process all its images.
`read_pilatus_diff` is convenient for spot checks, but its MAT reader loads the
whole containing chunk. It also reloads the manifest on each call.

Default arithmetic is double precision with a final conversion to single
precision. Use `OutputClass="double"` when the final single-precision rounding
is not acceptable. This doubles the output payload.

`Format="raw"` writes simple little-endian `.bin` chunks with the same array
order and a MAT manifest describing dimensions, class, ordering and inputs.
`read_pilatus_diff` uses a direct seek for a single raw output image. Keep the
manifest with the raw chunks. Benchmark this format rather than assuming it is
faster than uncompressed MAT.

MAT chunks use `-v7 -nocompression` and are limited here to 1.8 GB of image data,
leaving margin below the MAT v7 per-variable limit. Lower `ChunkFrames` when
using larger images or double output. Every parallel worker writes a separate
chunk, never a shared MAT/HDF5 file. Incomplete chunk writes retain a temporary
`.partial` filename. There is no automatic resume. Inspect completed chunks or
start in a new output directory after an interruption.

## Benchmark the actual storage

```matlab
T = benchmark_pilatus_diff(files, "E:\analysis\benchmark", 3, ...
    FilesPerTrial=2048);
```

This compares `Tiff` and `imread`, each with 1, 2 and 4 workers, including the
read -> compute -> write/close pipeline. Default output is uncompressed MAT.
It needs six disjoint input ranges, roughly 12,288 files for these settings
(rounding down each range to a multiple of six). Each trial's image output is
kept after a numerical spot check. A CSV and MAT results table are saved in a
new benchmark session folder. Allow roughly 20 GB of output space for six
trials with 2,048 ~10 MB inputs each at window 3 and single output. Source data
are never deleted. KeepOutputs=false removes the benchmark's own trial outputs
and is intended for smoke tests, not a durable-write throughput measurement.

Process pool startup is outside the timed section. TIFF reading is not supported
by `imread` in a thread pool. Close a pre-existing thread pool or undersized
process pool when necessary:

```matlab
p = gcp('nocreate');
if ~isempty(p), delete(p); end
```

The function will create a process pool automatically. When a larger process
pool is already open, a `parfor` worker limit is used for the smaller tests.
Serial processing uses an ordinary `for` loop, not `parfor(...,0)`.

Next compare the winning reader with output formats and chunk sizes:

```matlab
T = benchmark_pilatus_diff(files, "E:\analysis\benchmark", 3, ...
    FilesPerTrial=2048, Readers="tiff", WorkerCounts=[1 2 4], ...
    Formats=["mat" "raw"], ChunkFrames=64);
```

The benchmark does NOT guarantee cold OS caches or force disk/controller caches
to durable storage. Disjoint input ranges avoid the benchmark itself repeatedly
warming the same files, but previously read files may already be cached. Ranges
may differ in compression/size. Compare close candidates again, vary test order
or file ranges, and confirm the winner on a longer fresh range (for example,
5,000-10,000 ~10 MB input files on the stated 32 GB machine). Ensure there are
at least several chunks per worker. Do not report a small repeated in-RAM read
test as sustained disk throughput. Prefer a physical SSD/NVMe for inputs and,
where available, a separate physical SSD for outputs. Different drive letters
on one physical drive do not provide independent I/O bandwidth.

## Invalid pixels, precision, and ordering

`MaskNegative=true` is the default for raw photon-count data. A negative,
nonfinite, or explicitly flagged pixel in ANY input image makes the entire
corresponding output pixel NaN for that window. Zero is valid. This is a
conservative fixed-denominator policy, not an omit-NaN mean or frame rejection.

```matlab
r = pilatus_diff(files, outDir, 3, Workers=2, BadMask=~goodMask);
```

`BadMask` must be logical, with true meaning INVALID. Negative flag detection
does not detect flags stored as large unsigned values. After confirming the
actual encoding, set `BadValues`, for example `[4294967295 4294967294]` for a
verified uint32 -1/-2 bit-pattern convention. These are not assumed by default.
For already corrected data where negative intensities can be meaningful, use
`MaskNegative=false` and supply an appropriate explicit mask.

The code converts each input to the accumulator type BEFORE subtracting. This
avoids unsigned clipping/underflow and signed integer saturation. It subtracts
pairs first and accumulates their differences rather than accumulating two
large single-precision mean images. Double arithmetic retains every 32-bit
integer input count exactly; summed integers remain exact only while the
intermediate values stay within the double consecutive-integer range.

Single precision cannot represent all integers above 2^24 = 16,777,216.
`Accumulator="single"` is an optional performance experiment, not the default:
check both individual counts and accumulated sums before choosing it. Default
single OUTPUT is still a rounded representation; choose double output when
needed. No integer output is used because means may be fractional and
differences may be negative.

`pilatus_filelist` sorts by the last integer in a filename stem and rejects
missing/duplicated IDs or multiple naming patterns. Non-zero-padded names are
handled numerically. Nonstandard naming requires an explicitly ordered string
column vector from the acquisition log. The processing function trusts that
explicit ordering. Do not use timestamps or casually skip a missing image.

## Tests and limitations

```matlab
selftest_pilatus_diff
selftest_pilatus_diff(true)  % Also exercise two process workers.
```

The self-test creates tiny synthetic signed TIFFs and checks windows 1 and 3,
negative differences, large-count subtraction, mask propagation, numeric
filename sorting, missing-frame detection, and MAT/raw round trips.

These MATLAB scripts were written and statically checked in an environment
without a MATLAB runtime. The MATLAB self-test and the real TIFF benchmark
must be run on the target machine. No workstation performance measurements are
claimed. Run a small representative subset before the full acquisition.

There is no GPU path, fixed-header TIFF shortcut, live-acquisition retry,
recursive cross-run combination, automatic per-frame normalization, sliding
window mode, or metadata parsing beyond the TIFF reader. The file manifest
preserves source filenames and processing settings; detector metadata remain
in the original TIFFs. Keep the source data or a validated lossless archive.

## Design references

MathWorks documentation checked September 10, 2026:
- imread: TIFF reading is excluded from thread-pool support.
- Tiff/read: native TIFF image reading through the LibTIFF interface.
- save: v7/v7.3 `-nocompression`, v7 size limit, concurrent-write warning.
- flintmax: exact consecutive-integer limits for single/double precision.
- parfor: worker-limit syntax and independent loop iterations.
- fwrite: explicitly typed binary output.

NVIDIA CUDA Best Practices Guide: host/device transfers can outweigh simple
array addition/subtraction; minimize transfers rather than offload trivial
arithmetic merely because a GPU is present.
