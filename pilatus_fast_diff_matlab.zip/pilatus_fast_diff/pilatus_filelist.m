function [files,frameID,fileBytes] = pilatus_filelist(folder,pattern)
%PILATUS_FILELIST Numeric order for ONE acquisition; reject gaps/duplicates.
% [files,ids,bytes] = pilatus_filelist("D:\run1","sample_*.tif");
% Uses the LAST digit group in each filename stem as the frame ID.
% All remaining filename text must be identical across the series.
% Does not recurse or join acquisition conditions. No timestamp sorting.
% For other naming conventions, build files explicitly from acquisition logs.
arguments
    folder (1,1) string
    pattern (1,1) string = "*.tif"
end
assert(isfolder(folder),'pilatus:NoFolder','Input folder does not exist.');
q = dir(fullfile(folder,pattern));
q = q(~[q.isdir]);
assert(~isempty(q),'pilatus:NoFiles','No files match the requested pattern.');
n = numel(q);
frameID = zeros(n,1);
series = strings(n,1);
for k=1:n
    [~,stem,ext] = fileparts(q(k).name);
    [starts,ends] = regexp(stem,'\d+');
    assert(~isempty(starts),'pilatus:NoNumber', ...
        'No frame number in %s. Supply an explicitly ordered list instead.',q(k).name);
    a = starts(end); b = ends(end);
    frameID(k) = str2double(stem(a:b));
    assert(isfinite(frameID(k)) && frameID(k)<=flintmax, ...
        'pilatus:BadNumber','Frame number is too large or invalid.');
    series(k) = string(stem(1:a-1))+"#"+string(stem(b+1:end))+lower(string(ext));
end
assert(numel(unique(series))==1,'pilatus:MultipleSeries', ...
    'Pattern matches multiple naming series. Select one acquisition at a time.');
[frameID,order] = sort(frameID);
q = q(order);
assert(all(diff(frameID)==1),'pilatus:SequenceGap', ...
    'Frame IDs are missing or duplicated. Resolve against the acquisition log before pairing.');
files = strings(n,1);
for k=1:n, files(k)=fullfile(q(k).folder,q(k).name); end
fileBytes = reshape([q.bytes],[],1);
end
