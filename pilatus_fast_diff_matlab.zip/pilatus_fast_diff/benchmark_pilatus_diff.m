function results = benchmark_pilatus_diff(files,benchDir,window,opts)
%BENCHMARK_PILATUS_DIFF Compare end-to-end read/compute/write configurations.
% T = benchmark_pilatus_diff(files,"E:\bench",3,FilesPerTrial=2048);
% Default: Tiff vs imread, 1/2/4 workers, uncompressed MAT output.
% Compare raw separately using Readers="tiff",Formats=["mat","raw"].
%
% Each trial uses a DIFFERENT consecutive input range to avoid warming later
% trials by rereading the same images. This does NOT guarantee cold OS caches.
% Pool startup and initial probing are excluded; write/close calls are timed.
% Writes are buffered by the OS and are not a durable-storage benchmark.
% Trial subfolders are new and outputs are KEPT by default, avoiding deletion
% before deferred writes finish. KeepOutputs=false removes only these newly
% created trial outputs after a numerical spot check (for smoke tests).
% Source images are never modified.
arguments
    files (:,1) string
    benchDir (1,1) string
    window (1,1) double {mustBeInteger,mustBePositive}
    opts.FilesPerTrial (1,1) double {mustBeInteger,mustBePositive} = 2048
    opts.WorkerCounts (1,:) double {mustBeInteger,mustBePositive} = [1 2 4]
    opts.Readers (1,:) string = ["tiff" "imread"]
    opts.Formats (1,:) string = "mat"
    opts.ChunkFrames (1,1) double {mustBeInteger,mustBePositive} = 32
    opts.OutputClass (1,1) string {mustBeMember(opts.OutputClass,["single","double"])} = "single"
    opts.MaskNegative (1,1) logical = true
    opts.BadValues double = []
    opts.BadMask logical = []
    opts.KeepOutputs (1,1) logical = true
end
assert(all(ismember(opts.Readers,["tiff","imread"])),'pilatus:Reader','Invalid Reader.');
assert(all(ismember(opts.Formats,["mat","raw"])),'pilatus:Format','Invalid Format.');
nPer = floor(opts.FilesPerTrial/(2*window))*2*window;
assert(nPer>0,'pilatus:SmallTrial','Trial must contain at least 2*window files.');
nTrials = numel(opts.Readers)*numel(opts.Formats)*numel(opts.WorkerCounts);
assert(numel(files)>=nTrials*nPer,'pilatus:BenchmarkFiles', ...
    'Need %d distinct input files. Reduce FilesPerTrial or the number of configurations.',nTrials*nPer);
if ceil(nPer/(2*window)/opts.ChunkFrames)<2*max(opts.WorkerCounts)
    warning('pilatus:ShortBenchmark', ...
        'Few chunks per worker. Increase FilesPerTrial for a useful throughput comparison.');
end
if ~isfolder(benchDir), mkdir(benchDir); end
sessionDir = string(tempname(char(benchDir)));
mkdir(sessionDir);
fprintf('Benchmark results folder: %s\n',sessionDir);
fprintf('%d trials, %d distinct input files/trial.\n',nTrials,nPer);

% Verify both readers preserve the same numerical pixels on one sample.
reference = pilatus_read_tiff(files(1),"tiff");
if any(opts.Readers=="imread")
    alternate = pilatus_read_tiff(files(1),"imread");
    assert(isequaln(double(reference),double(alternate)), ...
        'pilatus:ReaderMismatch','Readers disagree on pixel values/orientation. Use Tiff and inspect the file.');
end
clear reference alternate

maxWorkers = max(opts.WorkerCounts);
if maxWorkers>1
    p = gcp('nocreate');
    if isempty(p), p = parpool('Processes',maxWorkers); end
    assert(~isa(p,'parallel.ThreadPool') && p.NumWorkers>=maxWorkers, ...
        'pilatus:BenchmarkPool', ...
        'Use a process pool with at least %d workers, or close the existing pool.',maxWorkers);
end

Reader = strings(nTrials,1); Format = Reader;
Workers = zeros(nTrials,1); Seconds = Workers; InputImagesPerSecond = Workers;
FirstInputPosition = Workers; LastInputPosition = Workers;
trial = 0;
for reader=opts.Readers
    for format=opts.Formats
        for workers=opts.WorkerCounts
            trial = trial+1;
            a = (trial-1)*nPer+1; b = trial*nPer;
            chosen = files(a:b);
            target = fullfile(sessionDir,compose("trial_%02d",trial));
            fprintf('Trial %d/%d: %s, %s, %d workers.\n',trial,nTrials,reader,format,workers);
            r = pilatus_diff(chosen,target,window,Workers=workers, ...
                Reader=reader,Format=format,ChunkFrames=opts.ChunkFrames, ...
                OutputClass=opts.OutputClass,MaskNegative=opts.MaskNegative, ...
                BadValues=opts.BadValues,BadMask=opts.BadMask,ShowProgress=false,TailPolicy="error");
            % Independent two-sum double reference, then matching output cast.
            first = pilatus_read_tiff(chosen(1),"tiff");
            even = zeros(size(first)); odd = even;
            for k=1:2*window
                raw = pilatus_read_tiff(chosen(k),"tiff");
                x = double(raw);
                if opts.MaskNegative, x(raw<0)=NaN; end
                for value=reshape(opts.BadValues,1,[]), x(raw==value)=NaN; end
                if isfloat(raw), x(~isfinite(raw))=NaN; end
                if mod(k,2)==0, even=even+x; else, odd=odd+x; end
            end
            expected = (even-odd)/window;
            if ~isempty(opts.BadMask), expected(opts.BadMask)=NaN; end
            expected = cast(expected,char(opts.OutputClass));
            actual = read_pilatus_diff(target,1);
            % Floating-point input can show reduction-order rounding differences.
            sameInvalid = isequal(isnan(actual),isnan(expected));
            good = isfinite(actual) & isfinite(expected);
            if any(good,'all')
                scale = max(1,max(abs(double(expected(good)))));
                tolerance = 32*double(eps(cast(scale,char(opts.OutputClass))))*window;
                errorSize = max(abs(double(actual(good))-double(expected(good))));
            else
                errorSize=0; tolerance=0;
            end
            assert(sameInvalid && errorSize<=tolerance,'pilatus:BenchmarkValidation', ...
                'Numerical spot-check failed; outputs retained at %s.',target);
            Reader(trial)=reader; Format(trial)=format; Workers(trial)=workers;
            Seconds(trial)=r.processingSeconds;
            InputImagesPerSecond(trial)=r.inputFramesPerSecond;
            FirstInputPosition(trial)=a; LastInputPosition(trial)=b;
            if ~opts.KeepOutputs, rmdir(target,'s'); end
        end
    end
end
results = table(Reader,Format,Workers,Seconds,InputImagesPerSecond, ...
    FirstInputPosition,LastInputPosition);
results = sortrows(results,'InputImagesPerSecond','descend');
save(fullfile(sessionDir,'benchmark_results.mat'),'results','opts','window','-v7','-nocompression');
writetable(results,fullfile(sessionDir,'benchmark_results.csv'));
disp(results)
fprintf('Confirm leading candidates on longer, previously unread data.\n');
fprintf('Disjoint input ranges can differ in size/compression, so repeat when rankings are close.\n');
end
