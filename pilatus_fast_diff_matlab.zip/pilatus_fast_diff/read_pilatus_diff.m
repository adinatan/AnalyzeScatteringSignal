function [D,sourceFiles] = read_pilatus_diff(outDir,index)
%READ_PILATUS_DIFF Read ONE output image by its global 1-based output index.
% [D,sourceFiles] = read_pilatus_diff("E:\diff_w3",1);
% Raw files support a direct seek. MAT v7 chunks are loaded in their entirety.
arguments
    outDir (1,1) string
    index (1,1) double {mustBeInteger,mustBePositive}
end
s = load(fullfile(outDir,'manifest.mat'),'manifest');
m = s.manifest;
assert(index<=m.nOutput,'pilatus:OutputIndex','Index exceeds the number of outputs.');
assert(m.complete,'pilatus:IncompleteRun','Run is incomplete; inspect completed chunks manually.');
c = find(index<=m.lastOutput,1);
local = index-m.firstOutput(c)+1;
file = fullfile(outDir,m.chunkNames(c));
if m.options.Format=="mat"
    v = load(file,'D');
    D = v.D(:,:,local);
else
    outputClass = char(m.options.OutputClass);
    bytesPerValue = 4+4*strcmp(outputClass,'double');
    [fid,msg] = fopen(file,'r','ieee-le');
    assert(fid~=-1,'pilatus:ReadOutput','Cannot open binary chunk: %s',msg);
    cleaner = onCleanup(@() fclose(fid)); %#ok<NASGU>
    status = fseek(fid,(local-1)*prod(m.imageSize)*bytesPerValue,'bof');
    assert(status==0,'pilatus:SeekOutput','Cannot seek to output image.');
    [D,count] = fread(fid,m.imageSize,['*' outputClass]);
    assert(count==prod(m.imageSize),'pilatus:TruncatedOutput','Incomplete output image.');
end
first = (index-1)*2*m.window+1;
sourceFiles = m.files(first:first+2*m.window-1);
end
